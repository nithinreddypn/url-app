<?php
header('Content-Type: text/plain');
$logFile = dirname(__DIR__) . '/storage/runtime/requests.log';
if (file_exists($logFile)) {
    echo file_get_contents($logFile);
} else {
    echo "requests.log does not exist yet.";
}
