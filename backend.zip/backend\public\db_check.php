<?php
declare(strict_types=1);

require_once dirname(__DIR__) . '/config/database.php';

header('Content-Type: text/plain');

try {
    // Reflection to read configuration and env from Database class
    $ref = new ReflectionClass('Database');
    
    $envMethod = $ref->getMethod('environmentValue');
    $envMethod->setAccessible(true);
    $appEnv = $envMethod->invoke(null, 'APP_ENV', 'development');
    $appDebug = $envMethod->invoke(null, 'APP_DEBUG', 'false');
    
    $localConfig = $ref->getConstant('LOCAL_CONFIGURATION');
    $prodConfig = $ref->getConstant('PRODUCTION_CONFIGURATION');
    
    $isLocalMethod = $ref->getMethod('isLocalRequest');
    $isLocalMethod->setAccessible(true);
    $isLocal = $isLocalMethod->invoke(null);
    
    echo "Diagnostic Information:\n";
    echo "-----------------------\n";
    echo "APP_ENV from environmentValue(): $appEnv\n";
    echo "APP_DEBUG from environmentValue(): $appDebug\n";
    echo "isLocalRequest() resolves to: " . ($isLocal ? "TRUE" : "FALSE") . "\n";
    
    $activeConfig = $isLocal ? $localConfig : $prodConfig;
    echo "Active Config Host: " . $activeConfig['host'] . "\n";
    echo "Active Config DB Name: " . $activeConfig['name'] . "\n";
    echo "Active Config User: " . $activeConfig['user'] . "\n";
    echo "Active Config Password Length: " . strlen($activeConfig['password']) . "\n\n";

    echo "Attempting raw PDO connection to the active configuration...\n";
    $dsn = sprintf(
        'mysql:host=%s;port=%s;dbname=%s;charset=utf8mb4',
        $activeConfig['host'],
        $activeConfig['port'],
        $activeConfig['name'],
    );
    
    $pdo = new PDO($dsn, $activeConfig['user'], $activeConfig['password'], [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION
    ]);
    echo "SUCCESS: Raw PDO Connection successful!\n";
    
} catch (Throwable $e) {
    echo "ERROR: " . $e->getMessage() . "\n";
    echo "File: " . $e->getFile() . " on line " . $e->getLine() . "\n";
}
