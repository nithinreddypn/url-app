<?php
declare(strict_types=1);

require_once dirname(__DIR__) . '/src/Support.php';
loadEnv(dirname(__DIR__) . '/.env');
require_once dirname(__DIR__) . '/src/Database.php';

header('Content-Type: text/plain');

try {
    $db = Database::connection();
    echo "Querying scans table:\n";
    echo "---------------------\n";
    
    $stmt = $db->query("SELECT id, url, verdict, risk_score, threat_category, scanned_at, created_at FROM scans ORDER BY created_at DESC LIMIT 5");
    $scans = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    foreach ($scans as $s) {
        echo "ID: " . $s['id'] . "\n";
        echo "URL: " . $s['url'] . "\n";
        echo "Verdict: " . $s['verdict'] . "\n";
        echo "Risk Score: " . $s['risk_score'] . "\n";
        echo "Threat Category: " . ($s['threat_category'] ?? 'NULL') . "\n";
        echo "Scanned At: " . ($s['scanned_at'] ?? 'NULL') . "\n";
        echo "Created At: " . $s['created_at'] . "\n\n";
    }
} catch (Throwable $e) {
    echo "ERROR: " . $e->getMessage() . "\n";
}
