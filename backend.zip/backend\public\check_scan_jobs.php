<?php
declare(strict_types=1);

require_once dirname(__DIR__) . '/src/Support.php';
loadEnv(dirname(__DIR__) . '/.env');
require_once dirname(__DIR__) . '/src/Database.php';

header('Content-Type: text/plain');

try {
    $db = Database::connection();
    echo "Querying scan_jobs table:\n";
    echo "-------------------------\n";
    
    $stmt = $db->query("SELECT id, scan_id, status, attempts, last_error, available_at, locked_at, locked_by, created_at FROM scan_jobs ORDER BY created_at DESC LIMIT 5");
    $jobs = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    foreach ($jobs as $j) {
        echo "Job ID: " . $j['id'] . "\n";
        echo "Scan ID: " . $j['scan_id'] . "\n";
        echo "Status: " . $j['status'] . "\n";
        echo "Attempts: " . $j['attempts'] . "\n";
        echo "Last Error: " . ($j['last_error'] ?? 'NULL') . "\n";
        echo "Available At: " . $j['available_at'] . "\n";
        echo "Locked At: " . ($j['locked_at'] ?? 'NULL') . "\n";
        echo "Created At: " . $j['created_at'] . "\n\n";
    }
} catch (Throwable $e) {
    echo "ERROR: " . $e->getMessage() . "\n";
}
