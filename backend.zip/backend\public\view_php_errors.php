<?php
header('Content-Type: text/plain');

function findErrorLogs($dir) {
    $found = [];
    $iterator = new RecursiveIteratorIterator(new RecursiveDirectoryIterator($dir));
    foreach ($iterator as $file) {
        if ($file->isFile() && (stripos($file->getFilename(), 'error') !== false || stripos($file->getFilename(), 'log') !== false)) {
            if (in_array($file->getExtension(), ['zip', 'sql', 'png', 'jpg', 'ttf', 'otf'])) continue;
            if ($file->getSize() > 0) {
                $found[] = $file->getPathname();
            }
        }
    }
    return $found;
}

$logs = findErrorLogs(dirname(__DIR__));
if (empty($logs)) {
    echo "No error logs found in backend directory.\n";
} else {
    foreach ($logs as $log) {
        echo "Log File: $log (" . filesize($log) . " bytes)\n";
        echo "----------------------------------------\n";
        $lines = file($log);
        $lastLines = array_slice($lines, -30);
        echo implode("", $lastLines);
        echo "\n\n";
    }
}
