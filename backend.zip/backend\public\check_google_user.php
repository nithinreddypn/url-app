<?php
declare(strict_types=1);

require_once dirname(__DIR__) . '/src/Support.php';
loadEnv(dirname(__DIR__) . '/.env');
require_once dirname(__DIR__) . '/src/Database.php';

header('Content-Type: text/plain');

try {
    $db = Database::connection();
    echo "Querying users table:\n";
    echo "---------------------\n";
    
    $stmt = $db->query("SELECT id, email, full_name, plan, email_verified_at, is_active, created_at FROM users ORDER BY created_at DESC LIMIT 5");
    $users = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    if (empty($users)) {
        echo "No users in database.\n";
    } else {
        foreach ($users as $u) {
            echo "ID: " . $u['id'] . "\n";
            echo "Email: " . $u['email'] . "\n";
            echo "Name: " . $u['full_name'] . "\n";
            echo "Verified At: " . ($u['email_verified_at'] ?? 'NULL') . "\n";
            echo "Created At: " . $u['created_at'] . "\n\n";
        }
    }
    
    echo "Pending Email Verifications / Resets:\n";
    echo "-------------------------------------\n";
    $evStmt = $db->query("SELECT user_id, expires_at, consumed_at, created_at FROM email_verifications ORDER BY created_at DESC LIMIT 5");
    $verifications = $evStmt->fetchAll(PDO::FETCH_ASSOC);
    foreach ($verifications as $ev) {
         echo "User ID: " . $ev['user_id'] . " | Created: " . $ev['created_at'] . " | Expires: " . $ev['expires_at'] . "\n";
    }
    
} catch (Throwable $e) {
    echo "ERROR: " . $e->getMessage() . "\n";
}
